/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmlapplication;

import java.net.URL;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Text;


public class FXMLDocumentController implements Initializable {
    @FXML
    private Text hora;
    
    
    
    //=========================================================
    // you must initialize here all related with the object 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        HoraTask tarea = new HoraTask();
        Thread hilo = new Thread(tarea);
        hilo.setDaemon(true);
        //hora.textProperty().bind(tarea.messageProperty());
        hilo.start();
    }

    class HoraTask extends Task<Void>{

        private long DELAY = 500;

        @Override
        protected Void call() throws Exception{
            while(true){
                Thread.sleep(DELAY);
                //     updateMessage(LocalTime.now().format(DateTimeFormatter.ofLocalizedTime(FormatStyle.MEDIUM)));
                Platform.runLater(()->{
                    hora.setText(LocalTime.now().format(DateTimeFormatter.ofLocalizedTime(FormatStyle.MEDIUM)));
                    });
            }
      }
        
    }
    
}
